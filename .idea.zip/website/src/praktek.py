import array as arr

a = arr.array('i', [1, 2, 3, 4, 5, 6])

print(a[0:int(len(a)/2)])